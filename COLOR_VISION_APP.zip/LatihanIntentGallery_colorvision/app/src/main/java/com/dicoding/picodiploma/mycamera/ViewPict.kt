package com.dicoding.picodiploma.mycamera

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import com.dicoding.picodiploma.mycamera.databinding.ActivityViewPictBinding
import com.example.test_aplikasi.TFLiteModel
import java.io.InputStream


class ViewPict : AppCompatActivity() {

    private lateinit var binding: ActivityViewPictBinding
    private lateinit var model: TFLiteModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewPictBinding.inflate(layoutInflater)
        setContentView(binding.root)

        model = TFLiteModel(assets, "model25Juli.tflite")

        val imageUriString = intent.getStringExtra("image_uri")
        val imageUri = imageUriString?.toUri()
        imageUri?.let { uri ->
            binding.viewPicture.setImageURI(uri)
        }?: Log.e("ViewPict", "No valid image URI provided")

        binding.deteksiBtn.setOnClickListener {
            imageUri?.let { uri ->
                val bitmap = getBitmapFromUri(uri)
                val input = preprocessImage(bitmap)
                val output = model.predict(input)

                // Menemukan kelas yang diprediksi
                val classIndices = arrayOf("MERAH", "BIRU", "KUNING", "HIJAU", "UNGU", "ORANYE")
                val predictedClassIndex = output.indices.maxByOrNull { output[it] } ?: -1
                //val maxConfidence = output[predictedClassIndex]

                // Menampilkan hasil
                val intent = Intent(this, ResultActivity::class.java).apply {
                    putExtra(ResultActivity.EXTRA_IMAGE_URI, imageUri.toString())
                    putExtra(ResultActivity.EXTRA_DETECTION_RESULT, classIndices[predictedClassIndex])
                    //putExtra(ResultActivity.EXTRA_CONFIDENCE, maxConfidence)
                }
                startActivity(intent)
            }
        }
    }

    private fun getBitmapFromUri(uri: Uri): Bitmap {
        val inputStream: InputStream? = contentResolver.openInputStream(uri)
        return BitmapFactory.decodeStream(inputStream)
    }

    private fun preprocessImage(bitmap: Bitmap): Array<Array<Array<FloatArray>>> {
        val resizedBitmap = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
        val input = Array(1) { Array(224) { Array(224) { FloatArray(3) } } }
        val intValues = IntArray(224 * 224)

        resizedBitmap.getPixels(intValues, 0, resizedBitmap.width, 0, 0, resizedBitmap.width, resizedBitmap.height)

        var pixel = 0
        for (i in 0 until 224) {
            for (j in 0 until 224) {
                val value = intValues[pixel++]
                input[0][i][j][0] = ((value shr 16) and 0xFF) / 255.0f
                input[0][i][j][1] = ((value shr 8) and 0xFF) / 255.0f
                input[0][i][j][2] = (value and 0xFF) / 255.0f
            }
        }

        return input
    }


}