package com.dicoding.picodiploma.mycamera

import android.app.Instrumentation.ActivityResult
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.util.Log
import android.widget.Toast
import androidx.core.net.toUri
import com.dicoding.picodiploma.mycamera.databinding.ActivityResultBinding
import java.util.Locale

class ResultActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityResultBinding
    private var textToSpeech: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Text-to-Speech
        textToSpeech = TextToSpeech(this, this)

        // Get the image URI and detection result from intent extras
        val imageUri = intent.getStringExtra(EXTRA_IMAGE_URI)?.toUri()
        val detectionResult = intent.getStringExtra(EXTRA_DETECTION_RESULT)
        //val confidence = intent.getFloatExtra(EXTRA_CONFIDENCE, 0f)

        imageUri?.let {
            binding.pictResult.setImageURI(it)
        }
        binding.textResult.text = detectionResult ?: "No result"

        //binding.textConfidence.text = "Confidence: $confidence"

        binding.buttonSpeak.setOnClickListener {
            speakOut()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale("id", "ID"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "Bahasa yang ditentukan tidak didukung!")
            }
        } else {
            Log.e("TTS", "Inisialisasi Gagal!")
        }
    }

    private fun speakOut() {
        val text = binding.textResult.text.toString()
        if (text.isNotEmpty()) {
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
        } else {
            Toast.makeText(this, "Tidak ada teks untuk dibacakan.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        // Shut down TTS
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_DETECTION_RESULT = "EXTRA_DETECTION_RESULT"
        const val EXTRA_IMAGE_URI = "EXTRA_IMAGE_URI"
        //const val EXTRA_CONFIDENCE = "EXTRA_CONFIDENCE"
    }
}
